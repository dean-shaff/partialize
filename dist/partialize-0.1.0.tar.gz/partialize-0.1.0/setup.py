# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['partialize']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'partialize',
    'version': '0.1.0',
    'description': 'Function partial decorator',
    'long_description': None,
    'author': 'Dean Shaff',
    'author_email': 'dshaff@swin.edu.au',
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
